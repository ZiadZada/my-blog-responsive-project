# My Blog — Expanded Responsive Project

This project continues the original My Blog website with `index.html`, `about.html`, `contact.html`, and the shared `css/Stylesheet.css`.

## New work
- Responsive layout: 1 column on small screens, 2 columns from 600px (tablet), and 3 columns from 900px (desktop).
- Reusable form styling for labels, text/email/number/date inputs, select, textarea, radio buttons, checkboxes, and buttons.
- Alert/notification styles.
- CSS-only modal using `:target` (no JavaScript).
- Dark mode using `@media (prefers-color-scheme: dark)`.
- Accessibility improvements: skip link, semantic landmarks, labelled navigation, current-page indication, form labels and fieldsets, keyboard focus styles, table caption/scoped headers, and reduced-motion preference.

## Validate HTML
Visit https://validator.w3.org/ and choose **Validate by File Upload**. Validate `contact.html` and ideally all three HTML files.

## Lighthouse accessibility audit
1. Open the website in Google Chrome.
2. Open DevTools with F12 (or Ctrl+Shift+I).
3. Select Lighthouse.
4. Select Accessibility and run the audit.
5. Fix any remaining issues reported by the audit. The final score must be confirmed by running Lighthouse in your browser; it is not claimed here without a real audit.

## Publish using GitHub Pages
1. Create a new GitHub repository.
2. Upload the files and preserve the `css` folder structure.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
5. Open the published URL after deployment completes.

Note: The contact form is front-end only and does not deliver messages without a backend or form service.
